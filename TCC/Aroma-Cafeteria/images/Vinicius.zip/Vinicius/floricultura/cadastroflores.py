import tkinter as tk
from tkinter import Button, Label, Entry, messagebox
import sqlite3

class acesso:
    def __init__(self):
        self.tela = tk.Tk()
        titulo = "Cadastro de flores"
        self.titulo = titulo
        self.tela.title(self.titulo)
        self.tela.geometry("400x300")
        self.com = sqlite3.connect("floricultura.db")
        self.cursor = self.com.cursor()
        self.cursor.execute("""CREATE TABLE IF NOT EXISTS flores(
                            id INTEGER PRIMARY KEY, 
                            nome TEXT, 
                            preco FLOAT,
                            quantidade INTEGER)""")

        self.nomelabel = tk.Label(self.tela, text="Nome da flor:")
        self.nomelabel.pack()
        self.nomentry = tk.Entry(self.tela, width=30)
        self.nomentry.pack()

        self.emailabel = tk.Label(self.tela, text="Email:")
        self.emailabel.pack()
        self.emailentry = tk.Entry(self.tela, width=30)
        self.emailentry.pack()

        self.senhalabel = tk.Label(self.tela, text="Senha:")
        self.senhalabel.pack()
        self.senhaentry = tk.Entry(self.tela, width=30)
        self.senhaentry.pack()

        self.acessarbutton = tk.Button(self.tela, text="Acessar", command=self.acessar)
        self.acessarbutton.pack()

        self.cadastrarbutton = tk.Button(self.tela, text="Cadastrar", command=self.cadastrar)
        self.cadastrarbutton.pack()

